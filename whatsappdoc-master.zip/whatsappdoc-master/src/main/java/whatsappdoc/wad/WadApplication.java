package whatsappdoc.wad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WadApplication {

    public static void main(String[] args) {
        SpringApplication.run(WadApplication.class, args);
    }
}
